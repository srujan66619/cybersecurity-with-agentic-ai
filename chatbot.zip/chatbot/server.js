const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
require("dotenv").config();

// Groq SDK
const Groq = require("groq-sdk");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Initialize Groq
const groqClient = new Groq({
  apiKey: process.env.GROQ_API_KEY,
});

// ------------------------------------------------------
// Chat endpoint — returns structured OWASP replies based on context
// ------------------------------------------------------
app.post("/chat", async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "Message required" });

    const lower = message.toLowerCase();
    let version = "";
    if (lower.includes("2017")) version = "2017";
    else if (lower.includes("2021")) version = "2021";
    else if (lower.includes("2025")) version = "2025";

    const lists = {
      "2017": `
OWASP Top 10 — 2017:
1. Injection
2. Broken Authentication
3. Sensitive Data Exposure
4. XML External Entities (XXE)
5. Broken Access Control
6. Security Misconfiguration
7. Cross-Site Scripting (XSS)
8. Insecure Deserialization
9. Using Components with Known Vulnerabilities
10. Insufficient Logging & Monitoring
      `,
      "2021": `
OWASP Top 10 — 2021:
1. A01:2021 Broken Access Control
2. A02:2021 Cryptographic Failures
3. A03:2021 Injection
4. A04:2021 Insecure Design
5. A05:2021 Security Misconfiguration
6. A06:2021 Vulnerable and Outdated Components
7. A07:2021 Identification & Authentication Failures
8. A08:2021 Software & Data Integrity Failures
9. A09:2021 Security Logging & Monitoring Failures
10. A10:2021 Server-Side Request Forgery (SSRF)
      `,
      "2025": `
OWASP Top 10 — 2025 (Release Candidate):
1. A01:2025 Broken Access Control
2. A02:2025 Security Misconfiguration
3. A03:2025 Software Supply Chain Failures
4. A04:2025 Cryptographic Failures
5. A05:2025 Injection
6. A06:2025 Insecure Design
7. A07:2025 Authentication Failures
8. A08:2025 Software & Data Integrity Failures
9. A09:2025 Logging & Alerting Failures
10. A10:2025 Mishandling of Exceptional Conditions
      `
    };

    let contextList = lists[version] || `
Use OWASP Top 10 as relevant; if the user asks about a specific year (2017, 2021, or 2025), tailor the risks accordingly.
${lists["2017"]}
${lists["2021"]}
${lists["2025"]}
    `;

    const structuredPrompt = `
You are a professional cybersecurity expert specializing in web application security using OWASP Top 10 standards.
Provide a clear, structured answer to the user’s question based on OWASP Top 10 concepts.

Include:
- A Title
- A concise Definition
- A numbered or bulleted Key Points list
- Examples
- Mitigation / Best Practices

Use the following OWASP list relevant to the user's query:
${contextList}

User question:
${message}
    `;

    const response = await groqClient.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: structuredPrompt },
        { role: "user", content: message },
      ],
      temperature: 0.2,
    });

    const replyText =
      response.choices?.[0]?.message?.content ||
      "Sorry, no answer available.";

    res.json({ reply: replyText });
  } catch (err) {
    console.error("AI error:", err);
    res.status(500).json({ error: "AI generation failed" });
  }
});

// ------------------------------------------------------
// Logging each chat message to a file
// ------------------------------------------------------
app.post("/log", (req, res) => {
  try {
    const { user, message, reply } = req.body;
    const logEntry = `${new Date().toISOString()} | ${user} | MSG: ${message} | AI: ${reply}\n`;
    fs.appendFileSync(path.join(__dirname, "chat-log.txt"), logEntry);
    res.status(200).json({ status: "logged" });
  } catch (err) {
    console.error("Log error:", err);
    res.status(500).json({ error: "Logging failed" });
  }
});

// ------------------------------------------------------
// Fallback — serve SPA
// ------------------------------------------------------
app.use((req, res) => {
  res.sendFile(path.join(__dirname, "public/index.html"));
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
